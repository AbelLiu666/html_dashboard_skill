# ECharts Configuration Patterns for Financial Scenarios

This reference provides complete, copy-paste-ready ECharts configuration objects
for common financial dashboard chart types. All examples use the CSS variable color
system defined in `color-palettes.md`.

## 1. Line Chart — Trend Over Time (折线图)

Best for: revenue trends, user growth, KPI tracking over time.

```javascript
const lineOption = {
  title: {
    text: '月度趋势',
    left: 'center',
    textStyle: { color: '#4a5568', fontSize: 14, fontWeight: 600 }
  },
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(26,54,93,0.9)',
    borderColor: '#3182ce',
    textStyle: { color: '#fff', fontSize: 12 },
    formatter: function(params) {
      return params.map(p =>
        `${p.marker} ${p.seriesName}: ${p.value.toLocaleString()}`
      ).join('<br/>');
    }
  },
  legend: {
    bottom: 0,
    textStyle: { color: '#718096', fontSize: 11 }
  },
  grid: { left: '3%', right: '4%', bottom: '10%', top: '15%', containLabel: true },
  xAxis: {
    type: 'category',
    boundaryGap: false,
    data: ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'],
    axisLine: { lineStyle: { color: '#e2e8f0' } },
    axisLabel: { color: '#a0aec0', fontSize: 11 }
  },
  yAxis: {
    type: 'value',
    splitLine: { lineStyle: { color: '#f0f0f0', type: 'dashed' } },
    axisLabel: {
      color: '#a0aec0',
      fontSize: 11,
      formatter: function(v) { return v >= 10000 ? (v/10000).toFixed(1)+'w' : v; }
    }
  },
  series: [{
    name: '指标A',
    type: 'line',
    smooth: true,
    symbol: 'circle',
    symbolSize: 6,
    lineStyle: { width: 2, color: '#3182ce' },
    itemStyle: { color: '#3182ce' },
    areaStyle: {
      color: {
        type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
        colorStops: [
          { offset: 0, color: 'rgba(49,130,206,0.25)' },
          { offset: 1, color: 'rgba(49,130,206,0.02)' }
        ]
      }
    },
    data: [120, 132, 101, 134, 190, 230, 210, 182, 191, 234, 290, 330]
  }]
};
```

## 2. Bar Chart — Category Comparison (柱状图)

Best for: product comparison, feature scoring, department performance.

```javascript
const barOption = {
  title: {
    text: '指标对比',
    left: 'center',
    textStyle: { color: '#4a5568', fontSize: 14, fontWeight: 600 }
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: { type: 'shadow' },
    backgroundColor: 'rgba(26,54,93,0.9)',
    textStyle: { color: '#fff', fontSize: 12 }
  },
  grid: { left: '3%', right: '4%', bottom: '10%', top: '15%', containLabel: true },
  xAxis: {
    type: 'category',
    data: ['产品A', '产品B', '产品C', '产品D', '产品E'],
    axisLabel: { color: '#a0aec0', fontSize: 11 },
    axisLine: { lineStyle: { color: '#e2e8f0' } }
  },
  yAxis: {
    type: 'value',
    splitLine: { lineStyle: { color: '#f0f0f0', type: 'dashed' } },
    axisLabel: { color: '#a0aec0', fontSize: 11 }
  },
  series: [{
    name: '得分',
    type: 'bar',
    barWidth: '50%',
    itemStyle: {
      borderRadius: [4, 4, 0, 0],
      color: {
        type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
        colorStops: [
          { offset: 0, color: '#63b3ed' },
          { offset: 1, color: '#3182ce' }
        ]
      }
    },
    label: {
      show: true,
      position: 'top',
      color: '#4a5568',
      fontSize: 11,
      fontWeight: 600
    },
    data: [85, 72, 93, 66, 78]
  }]
};
```

## 3. Pie Chart — Proportion Breakdown (饼图)

Best for: market share, budget allocation, user distribution.

```javascript
const pieOption = {
  title: {
    text: '占比分布',
    left: 'center',
    textStyle: { color: '#4a5568', fontSize: 14, fontWeight: 600 }
  },
  tooltip: {
    trigger: 'item',
    backgroundColor: 'rgba(26,54,93,0.9)',
    textStyle: { color: '#fff', fontSize: 12 },
    formatter: '{b}: {c} ({d}%)'
  },
  legend: {
    orient: 'vertical',
    right: '5%',
    top: 'center',
    textStyle: { color: '#718096', fontSize: 11 }
  },
  series: [{
    type: 'pie',
    radius: ['45%', '70%'],
    center: ['40%', '50%'],
    avoidLabelOverlap: false,
    itemStyle: {
      borderRadius: 6,
      borderColor: '#fff',
      borderWidth: 2
    },
    label: {
      show: false
    },
    emphasis: {
      label: {
        show: true,
        fontSize: 16,
        fontWeight: 'bold'
      }
    },
    data: [
      { value: 1048, name: '类别A' },
      { value: 735, name: '类别B' },
      { value: 580, name: '类别C' },
      { value: 484, name: '类别D' },
      { value: 300, name: '类别E' }
    ]
  }]
};
```

## 4. Radar Chart — Multi-Dimension Scoring (雷达图)

Best for: competitive analysis, capability assessment, product scoring.

```javascript
const radarOption = {
  title: {
    text: '能力雷达',
    left: 'center',
    textStyle: { color: '#4a5568', fontSize: 14, fontWeight: 600 }
  },
  tooltip: {
    trigger: 'item',
    backgroundColor: 'rgba(26,54,93,0.9)',
    textStyle: { color: '#fff', fontSize: 12 }
  },
  legend: {
    bottom: 0,
    textStyle: { color: '#718096', fontSize: 11 }
  },
  radar: {
    center: ['50%', '45%'],
    radius: '65%',
    indicator: [
      { name: '维度A', max: 100 },
      { name: '维度B', max: 100 },
      { name: '维度C', max: 100 },
      { name: '维度D', max: 100 },
      { name: '维度E', max: 100 }
    ],
    axisName: { color: '#4a5568', fontSize: 11 },
    splitArea: {
      areaStyle: { color: ['rgba(49,130,206,0.02)', 'rgba(49,130,206,0.05)'] }
    }
  },
  series: [{
    type: 'radar',
    symbol: 'circle',
    symbolSize: 4,
    lineStyle: { width: 2 },
    areaStyle: { opacity: 0.15 },
    data: [
      { value: [85, 72, 90, 65, 78], name: '我方产品' },
      { value: [70, 80, 75, 82, 70], name: '竞品A' }
    ]
  }]
};
```

## 5. Dual-Axis Chart — Two Metrics Comparison (双轴图)

Best for: comparing metrics with different scales (e.g., revenue vs growth rate).

```javascript
const dualAxisOption = {
  title: {
    text: '双指标对比',
    left: 'center',
    textStyle: { color: '#4a5568', fontSize: 14, fontWeight: 600 }
  },
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(26,54,93,0.9)',
    textStyle: { color: '#fff', fontSize: 12 },
    formatter: function(params) {
      let result = params[0].axisValue + '<br/>';
      params.forEach(function(p) {
        result += p.marker + ' ' + p.seriesName + ': ' + p.value + (p.seriesIndex === 1 ? '%' : '') + '<br/>';
      });
      return result;
    }
  },
  legend: {
    bottom: 0,
    textStyle: { color: '#718096', fontSize: 11 }
  },
  grid: { left: '5%', right: '5%', bottom: '10%', top: '15%', containLabel: true },
  xAxis: {
    type: 'category',
    data: ['Q1', 'Q2', 'Q3', 'Q4'],
    axisLabel: { color: '#a0aec0', fontSize: 11 }
  },
  yAxis: [
    {
      type: 'value',
      name: '金额(万)',
      nameTextStyle: { color: '#a0aec0', fontSize: 11 },
      splitLine: { lineStyle: { color: '#f0f0f0', type: 'dashed' } },
      axisLabel: { color: '#a0aec0', fontSize: 11 }
    },
    {
      type: 'value',
      name: '增长率(%)',
      nameTextStyle: { color: '#a0aec0', fontSize: 11 },
      axisLabel: {
        color: '#a0aec0',
        fontSize: 11,
        formatter: '{value}%'
      }
    }
  ],
  series: [
    {
      name: '营收',
      type: 'bar',
      barWidth: '35%',
      itemStyle: {
        borderRadius: [4, 4, 0, 0],
        color: '#3182ce'
      },
      data: [320, 450, 380, 520]
    },
    {
      name: '增长率',
      type: 'line',
      yAxisIndex: 1,
      smooth: true,
      symbol: 'circle',
      symbolSize: 8,
      lineStyle: { width: 2, color: '#38a169' },
      itemStyle: { color: '#38a169' },
      data: [12, 18, 8, 22]
    }
  ]
};
```

## 6. Scatter Chart — Distribution Analysis (散点图)

Best for: correlation analysis, outlier detection, cluster visualization.

```javascript
const scatterOption = {
  title: {
    text: '分布分析',
    left: 'center',
    textStyle: { color: '#4a5568', fontSize: 14, fontWeight: 600 }
  },
  tooltip: {
    trigger: 'item',
    backgroundColor: 'rgba(26,54,93,0.9)',
    textStyle: { color: '#fff', fontSize: 12 },
    formatter: function(p) { return p.seriesName + '<br/>X: ' + p.value[0] + '<br/>Y: ' + p.value[1]; }
  },
  grid: { left: '3%', right: '4%', bottom: '10%', top: '15%', containLabel: true },
  xAxis: {
    type: 'value',
    name: '指标X',
    splitLine: { lineStyle: { color: '#f0f0f0', type: 'dashed' } },
    axisLabel: { color: '#a0aec0', fontSize: 11 }
  },
  yAxis: {
    type: 'value',
    name: '指标Y',
    splitLine: { lineStyle: { color: '#f0f0f0', type: 'dashed' } },
    axisLabel: { color: '#a0aec0', fontSize: 11 }
  },
  series: [{
    name: '产品分布',
    type: 'scatter',
    symbolSize: function(val) { return val[2] * 2; },
    itemStyle: {
      color: '#3182ce',
      shadowBlur: 10,
      shadowColor: 'rgba(49,130,206,0.3)'
    },
    data: [
      [10.0, 8.0, 15], [20.0, 15.0, 20], [15.0, 12.0, 25],
      [25.0, 18.0, 10], [30.0, 25.0, 18], [18.0, 10.0, 22],
      [22.0, 20.0, 12], [28.0, 22.0, 16], [12.0, 7.0, 8]
    ]
  }]
};
```

## Color Application for Charts

When generating chart options, map the palette's chart colors to series:

```javascript
const chartColors = [
  '#3182ce', // --color-chart-1
  '#38a169', // --color-chart-2
  '#d69e2e', // --color-chart-3
  '#e53e3e', // --color-chart-4
  '#805ad5', // --color-chart-5
  '#dd6b20'  // --color-chart-6
];

// Apply to all series
option.color = chartColors;
```

## Responsive Handling

Always initialize charts after the DOM element is visible (not `display: none`).
When a page becomes active (sidebar switch), resize all charts on that page:

```javascript
function resizeChartsOnPage(pageId) {
  Object.entries(chartInstances).forEach(([id, chart]) => {
    if (id.startsWith(pageId + '-')) {
      chart.resize();
    }
  });
}
```
