# Financial-Grade Color Palettes

Each palette defines a complete CSS variable set for a single-color-family gradient scheme.
All palettes are low-saturation, muted, and professional — suitable for financial/AI product dashboards.

## Palette 1: Deep Navy (深海军蓝) — Default

```
--color-primary: #1a365d;
--color-primary-light: #2a4a7f;
--color-primary-lighter: #3b5fa0;
--color-primary-dark: #0f2440;
--color-accent: #3182ce;
--color-accent-light: #63b3ed;
--color-accent-dark: #2b6cb0;
--color-bg-sidebar: linear-gradient(180deg, #0f2440 0%, #1a365d 50%, #0f2440 100%);
--color-bg-main: #f0f2f5;
--color-bg-card: #ffffff;
--color-bg-card-hover: #f7fafc;
--color-text-primary: #1a202c;
--color-text-secondary: #4a5568;
--color-text-muted: #a0aec0;
--color-text-sidebar: #cbd5e0;
--color-text-sidebar-active: #ffffff;
--color-border: #e2e8f0;
--color-success: #38a169;
--color-warning: #d69e2e;
--color-danger: #e53e3e;
--color-chart-1: #3182ce;
--color-chart-2: #38a169;
--color-chart-3: #d69e2e;
--color-chart-4: #e53e3e;
--color-chart-5: #805ad5;
--color-chart-6: #dd6b20;
--gradient-hero: linear-gradient(135deg, #1a365d 0%, #2a4a7f 50%, #3182ce 100%);
--gradient-card: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
```

## Palette 2: Forest Teal (森林青)

```
--color-primary: #1a4731;
--color-primary-light: #276749;
--color-primary-lighter: #388a62;
--color-primary-dark: #0d2b1d;
--color-accent: #319795;
--color-accent-light: #4fd1c5;
--color-accent-dark: #2c7a7b;
--color-bg-sidebar: linear-gradient(180deg, #0d2b1d 0%, #1a4731 50%, #0d2b1d 100%);
--color-bg-main: #f0f5f2;
--color-bg-card: #ffffff;
--color-bg-card-hover: #f0faf5;
--color-text-primary: #1a202c;
--color-text-secondary: #4a5568;
--color-text-muted: #a0aec0;
--color-text-sidebar: #c6d6cf;
--color-text-sidebar-active: #ffffff;
--color-border: #e2e8e0;
--color-success: #38a169;
--color-warning: #d69e2e;
--color-danger: #e53e3e;
--color-chart-1: #319795;
--color-chart-2: #38a169;
--color-chart-3: #d69e2e;
--color-chart-4: #e53e3e;
--color-chart-5: #805ad5;
--color-chart-6: #dd6b20;
--gradient-hero: linear-gradient(135deg, #1a4731 0%, #276749 50%, #319795 100%);
--gradient-card: linear-gradient(135deg, #f0faf5 0%, #e6f5ed 100%);
```

## Palette 3: Royal Purple (皇家紫)

```
--color-primary: #322659;
--color-primary-light: #44337a;
--color-primary-lighter: #553c9a;
--color-primary-dark: #1a1335;
--color-accent: #805ad5;
--color-accent-light: #b794f4;
--color-accent-dark: #6b46c1;
--color-bg-sidebar: linear-gradient(180deg, #1a1335 0%, #322659 50%, #1a1335 100%);
--color-bg-main: #f5f3fa;
--color-bg-card: #ffffff;
--color-bg-card-hover: #faf5ff;
--color-text-primary: #1a202c;
--color-text-secondary: #4a5568;
--color-text-muted: #a0aec0;
--color-text-sidebar: #d6cde8;
--color-text-sidebar-active: #ffffff;
--color-border: #e9e0f0;
--color-success: #38a169;
--color-warning: #d69e2e;
--color-danger: #e53e3e;
--color-chart-1: #805ad5;
--color-chart-2: #38a169;
--color-chart-3: #d69e2e;
--color-chart-4: #e53e3e;
--color-chart-5: #3182ce;
--color-chart-6: #dd6b20;
--gradient-hero: linear-gradient(135deg, #322659 0%, #44337a 50%, #805ad5 100%);
--gradient-card: linear-gradient(135deg, #faf5ff 0%, #f0e8fa 100%);
```

## Palette 4: Slate Gray (岩板灰)

```
--color-primary: #2d3748;
--color-primary-light: #4a5568;
--color-primary-lighter: #718096;
--color-primary-dark: #1a202c;
--color-accent: #4299e1;
--color-accent-light: #63b3ed;
--color-accent-dark: #3182ce;
--color-bg-sidebar: linear-gradient(180deg, #1a202c 0%, #2d3748 50%, #1a202c 100%);
--color-bg-main: #f7fafc;
--color-bg-card: #ffffff;
--color-bg-card-hover: #edf2f7;
--color-text-primary: #1a202c;
--color-text-secondary: #4a5568;
--color-text-muted: #a0aec0;
--color-text-sidebar: #cbd5e0;
--color-text-sidebar-active: #ffffff;
--color-border: #e2e8f0;
--color-success: #38a169;
--color-warning: #d69e2e;
--color-danger: #e53e3e;
--color-chart-1: #4299e1;
--color-chart-2: #38a169;
--color-chart-3: #d69e2e;
--color-chart-4: #e53e3e;
--color-chart-5: #805ad5;
--color-chart-6: #dd6b20;
--gradient-hero: linear-gradient(135deg, #2d3748 0%, #4a5568 50%, #4299e1 100%);
--gradient-card: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
```

## Palette 5: Burgundy Wine (勃艮第红)

```
--color-primary: #742a2a;
--color-primary-light: #9b2c2c;
--color-primary-lighter: #c53030;
--color-primary-dark: #4a1a1a;
--color-accent: #e53e3e;
--color-accent-light: #fc8181;
--color-accent-dark: #c53030;
--color-bg-sidebar: linear-gradient(180deg, #4a1a1a 0%, #742a2a 50%, #4a1a1a 100%);
--color-bg-main: #fefaf5;
--color-bg-card: #ffffff;
--color-bg-card-hover: #fff5f5;
--color-text-primary: #1a202c;
--color-text-secondary: #4a5568;
--color-text-muted: #a0aec0;
--color-text-sidebar: #e8c8c8;
--color-text-sidebar-active: #ffffff;
--color-border: #f0e0e0;
--color-success: #38a169;
--color-warning: #d69e2e;
--color-danger: #e53e3e;
--color-chart-1: #c53030;
--color-chart-2: #dd6b20;
--color-chart-3: #d69e2e;
--color-chart-4: #3182ce;
--color-chart-5: #805ad5;
--color-chart-6: #38a169;
--gradient-hero: linear-gradient(135deg, #742a2a 0%, #9b2c2c 50%, #c53030 100%);
--gradient-card: linear-gradient(135deg, #fff5f5 0%, #fee8e8 100%);
```

## Palette 6: Midnight Indigo (午夜靛蓝)

```
--color-primary: #1e1b4b;
--color-primary-light: #312e81;
--color-primary-lighter: #4338ca;
--color-primary-dark: #11103d;
--color-accent: #6366f1;
--color-accent-light: #a5b4fc;
--color-accent-dark: #4f46e5;
--color-bg-sidebar: linear-gradient(180deg, #11103d 0%, #1e1b4b 50%, #11103d 100%);
--color-bg-main: #f5f3ff;
--color-bg-card: #ffffff;
--color-bg-card-hover: #eef2ff;
--color-text-primary: #1a202c;
--color-text-secondary: #4a5568;
--color-text-muted: #a0aec0;
--color-text-sidebar: #c7d2fe;
--color-text-sidebar-active: #ffffff;
--color-border: #e0e7ff;
--color-success: #38a169;
--color-warning: #d69e2e;
--color-danger: #e53e3e;
--color-chart-1: #6366f1;
--color-chart-2: #38a169;
--color-chart-3: #d69e2e;
--color-chart-4: #e53e3e;
--color-chart-5: #3182ce;
--color-chart-6: #dd6b20;
--gradient-hero: linear-gradient(135deg, #1e1b4b 0%, #312e81 50%, #6366f1 100%);
--gradient-card: linear-gradient(135deg, #eef2ff 0%, #e0e7ff 100%);
```

## Usage

When generating a page, pick the palette matching the user's color preference.
Replace the `:root { ... }` CSS block in the template with the chosen palette's variables.
All page elements reference these CSS variables, so the entire page theme switches cleanly.

If the user says "深蓝" → Palette 1 (Deep Navy)
If "青色/绿色/森林" → Palette 2 (Forest Teal)
If "紫色" → Palette 3 (Royal Purple)
If "灰色/商务灰" → Palette 4 (Slate Gray)
If "红色/酒红" → Palette 5 (Burgundy Wine)
If "靛蓝/紫蓝" → Palette 6 (Midnight Indigo)
