---
name: fintech-html-dashboard
description: Generate complete production-ready single-file HTML dashboards for financial AI product scenarios. This skill should be used when the user requests financial dashboards, AI product demo pages, competitive analysis pages, business requirement visualization boards, industry research dashboards, financial data visualization pages, or any HTML page with sidebar navigation and ECharts charts for finance/AI product expert workflows. Trigger phrases include financial dashboard requests, data visualization boards, product demo prototypes, competitive analysis pages, and business requirement document displays. The skill enforces a strict sidebar-and-content layout, ECharts integration, smart customer service floating widget, and financial-grade color schemes.
---

# Fintech HTML Dashboard Generator

## Overview

Generate a complete, self-contained single-file HTML page tailored for financial AI product experts.
The output is a ready-to-run HTML file that opens directly in any browser — zero dependencies except
the ECharts CDN (auto-loaded). Every generated page follows a strict structural contract and visual
standard defined below.

## When to Use This Skill

Trigger this skill when the user asks for any of the following:

- "帮我生成一个金融看板页面"
- "做一个AI外呼产品的演示Demo"
- "生成竞品分析可视化页面"
- "做一个业务需求调研看板"
- "生成HTML页面" combined with finance/product context
- Any request matching "dashboard" / "看板" / "可视化" / "产品原型" in a financial or AI product context

## Input Collection

Before generating, collect or infer these 5 inputs from the user:

| # | Input | Description |
|---|-------|-------------|
| 1 | **Business Background** | What the page is for (e.g., AI outbound call product analysis) |
| 2 | **Target Audience** | Who will view the page (e.g., product managers, executives) |
| 3 | **Expected Goal** | What the page should achieve (e.g., demo presentation, data review) |
| 4 | **Reference Materials** | Any data, documents, or examples provided |
| 5 | **Primary Color Scheme** | The main color for gradient theming (e.g., deep blue, teal, navy) |

If any of these are not explicitly provided, infer reasonable defaults based on the context.
Ask the user only if critical ambiguity exists.

## Mandatory Page Structure (Non-Negotiable)

### Layout: Left Sidebar + Right Content Area

```
+------------------+----------------------------------------+
|                  |                                        |
|   SIDEBAR        |        MAIN CONTENT AREA               |
|   (240px)        |        (flex: 1)                       |
|                  |                                        |
|   [Nav Item 1]   |   +-------------------------------+   |
|   [Nav Item 2]   |   |                               |   |
|   [Nav Item 3]   |   |   Page content switches       |   |
|   [Nav Item 4]   |   |   based on sidebar selection  |   |
|   ...            |   |                               |   |
|                  |   +-------------------------------+   |
|                  |                                        |
|   [By 🌟🌟]      |                                        |
+------------------+----------------------------------------+
                                            [💬 Chat Float]
```

**Rules:**

1. **Sidebar** (left, fixed width 240px):
   - Contains navigation buttons that switch right-side content
   - Each button corresponds to one "page" / module
   - Active state: highlighted with accent color background
   - Hover state: subtle background transition
   - **Bottom of sidebar**: signature area with emoji + "By Abel" text, centered, subtle styling
   - The signature area is always visible, anchored at sidebar bottom

2. **Main Content Area** (right, flexible width):
   - Only ONE page visible at a time
   - Switching sidebar nav hides current page, shows selected page
   - No single-page flat layout — always multi-page tab switching

3. **Smart Customer Service Float** (bottom-right corner):
   - Fixed position floating icon button
   - Click to expand a chat dialog window
   - Dialog includes: header with title, message area, input field + send button
   - Can be closed (X) or minimized (-) from dialog header
   - Dialog styling matches the page's gradient color scheme
   - Auto-responds to questions about page content, data, modules, logic
   - Simple rule-based responses: scan page content for keywords and generate contextual answers

### Sidebar Signature Area

At the bottom of the sidebar, add a signature block:

```html
<div class="sidebar-signature">
  <span class="signature-emoji">🐂</span>
  <span class="signature-text">By 🌟🌟</span>
</div>
```

Style it with:
- Centered horizontally within sidebar
- Subtle opacity (0.6-0.7), increases on hover
- Small font size (12-13px)
- Positioned at the absolute bottom of sidebar using flexbox or absolute positioning
- The emoji can be customized per user preference; default to 🐂 (ox, matching "牛牛Voice" branding)

## Visual UI Standards

### Color System

- Use a **single color family gradient** throughout the entire page
- **Financial-grade**: low saturation, muted, professional — never neon or high-saturation
- The sidebar background uses a darker variant of the main color
- Content area background is light/neutral (e.g., #f5f7fa)
- Cards, charts, and widgets use white or very light backgrounds
- Customer service float and dialog match the gradient theme
- **Reference**: see `references/color-palettes.md` for preset color schemes

### Typography

- Clean, sans-serif font stack: `-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif`
- Extremely concise text — only essential information, no verbose paragraphs
- Clear hierarchy: titles (18-22px), section headers (14-16px), data labels (12-13px), annotations (11px)
- Use font-weight and color (not size alone) to establish hierarchy

### Spacing & Layout

- Card-based content organization within each page
- Generous whitespace between sections
- Consistent padding (20-24px for cards, 16-20px for inner content)
- Rounded corners (8-12px) on cards and interactive elements

## Chart Integration (ECharts)

### Loading

Include ECharts CDN in `<head>`:
```html
<script src="https://cdn.jsdelivr.net/npm/echarts@5.5.0/dist/echarts.min.js"></script>
```

### Chart Types & Auto-Selection

Choose the appropriate chart type based on data semantics:

| Data Pattern | Chart Type | ECharts Series |
|-------------|-----------|----------------|
| Time series, trends over time | Line chart | `type: 'line'` |
| Category comparison, rankings | Bar chart | `type: 'bar'` |
| Proportion, percentage breakdown | Pie chart | `type: 'pie'` |
| Multi-dimensional scoring | Radar chart | `type: 'radar'` |
| Dual metric comparison | Dual-axis chart | Two yAxis + line+bar |
| Distribution patterns | Scatter/area | `type: 'scatter'` / `type: 'line'` with `areaStyle` |

### Chart Requirements

- Every chart MUST have: title, legend, tooltip (with value formatting), clearly labeled axes
- Use `tooltip` with `trigger: 'axis'` or `trigger: 'item'` for data-on-hover
- Color palette within each chart matches the page's main color scheme
- Chart container uses `width: 100%` and a fixed aspect ratio (typically 16:9 or 4:3)
- Initialize charts AFTER DOM is ready and after switching to their parent page
- Handle chart resize on window resize with `window.addEventListener('resize', ...)`
- Charts on non-visible pages should be resized when their page becomes active

### Chart Initialization Pattern

```javascript
// Store chart instances for resize management
const chartInstances = {};

function initChart(containerId, option) {
  const dom = document.getElementById(containerId);
  if (!dom) return;
  if (chartInstances[containerId]) {
    chartInstances[containerId].dispose();
  }
  const chart = echarts.init(dom);
  chart.setOption(option);
  chartInstances[containerId] = chart;
}

// Resize handler
window.addEventListener('resize', () => {
  Object.values(chartInstances).forEach(c => c.resize());
});
```

## Customer Service Widget

### Structure

```html
<!-- Float Button -->
<div class="cs-float-btn" id="csFloatBtn">
  <span>💬</span>
</div>

<!-- Chat Dialog -->
<div class="cs-dialog" id="csDialog" style="display:none">
  <div class="cs-dialog-header">
    <span>智能客服</span>
    <div class="cs-dialog-actions">
      <button class="cs-minimize-btn">−</button>
      <button class="cs-close-btn">×</button>
    </div>
  </div>
  <div class="cs-dialog-body" id="csMessages"></div>
  <div class="cs-dialog-footer">
    <input type="text" id="csInput" placeholder="输入问题..." />
    <button id="csSendBtn">发送</button>
  </div>
</div>
```

### Interaction Logic

1. Click float button → show dialog, hide button (or keep button visible)
2. Click close (×) → hide dialog, show float button
3. Click minimize (−) → hide dialog, show float button
4. Type in input + click send or press Enter → add user message, generate auto-response
5. Auto-response logic: scan user input for keywords, match against page content, return contextual answer

### Auto-Response Rules

Build a keyword-response map based on the generated page content:

```javascript
const knowledgeBase = {
  '数据|图表|指标': '当前页面展示了核心业务数据可视化图表...',
  '功能|模块|页面': '本看板包含以下功能模块：...',
  '颜色|配色|主题': '页面采用金融级低饱和渐变配色...',
  '技术|架构|实现': '页面基于HTML5+ECharts构建...',
  'default': '您好！我是智能客服，可以回答关于当前页面的问题。请尝试询问页面功能、数据图表或技术实现等方面的问题。'
};
```

## Business Scenario Adaptation

This skill is optimized for the following scenarios of a **financial AI product expert**:

1. **Business Requirement Research Dashboard** — visualize survey data, feature priorities, market needs
2. **Standardized Requirement Document Display** — present PRD/BRD content in a structured, navigable format
3. **Competitive Analysis Page** — side-by-side feature comparison, market positioning radar charts
4. **Market/Industry Research Dashboard** — trends, market share, growth projections
5. **Product Demo Prototype** — interactive demo for stakeholder presentations

## Code Output Rules

1. **Single file** — output the complete HTML in one code block, never split
2. **Key comments** — annotate sidebar switching, chart rendering, color scheme, and CS widget logic
3. **Self-contained** — all CSS and JS inline; only external dependency is ECharts CDN
4. **Browser-ready** — copy the code, save as `.html`, open directly in any modern browser
5. **Responsive** — adapts to common desktop resolutions (1366px - 1920px width)
6. **Signature** — always include the "By 🌟🌟" signature at sidebar bottom

## Template Reference

Use `assets/template.html` as the starting skeleton. It contains:
- Complete sidebar + content layout structure
- ECharts integration boilerplate
- Customer service widget with full interaction logic
- CSS reset and base styling
- Chart initialization and page switching JavaScript

When generating a new page from the template, customize:
- Page titles and navigation items based on the 5 inputs
- Chart data and configurations based on reference materials
- Color scheme based on the primary color input
- Content cards and text based on business context
- Knowledge base entries for the CS widget based on page content

## Resources

### references/color-palettes.md
Preset financial-grade color schemes. Load when the user specifies a color preference to find the
matching palette definition. Contains CSS variable sets for 6 financial color themes.

### references/chart-patterns.md
ECharts configuration patterns for common financial scenarios. Load when generating charts to
reference the appropriate option structure. Contains complete config examples for line, bar, pie,
radar, dual-axis, and scatter charts with financial data styling.

### assets/template.html
The complete HTML template skeleton. Copy and customize this file for each generation. Contains
all structural elements, CSS, and JavaScript needed for a working page.
